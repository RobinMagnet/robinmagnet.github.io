# modelnet_dataset.py

import numpy as np
import torch
import torch.nn as nn
import h5py
import os
import os.path as osp

from pathlib import Path
from glob import glob
from tqdm import tqdm
from torch.utils.data import Dataset

from trimesh.transformations import rotation_matrix as RotMat

def load_h5(h5_filename):
    f = h5py.File(h5_filename)
    print(h5_filename)
    data = f['data'][:]
    label = f['label'][:]
    f.close()
    return (data, label)

def load_h5_files(data_path, files_list_path):
    """Load h5 into memory
    """
    files_list = [Path(line.rstrip()).name for line in open(osp.join(data_path, files_list_path))]
    data = []
    labels = []
    for i in range(len(files_list)):
        data_, labels_ = load_h5(os.path.join(data_path, files_list[i]))
        data.append(data_)
        labels.append(labels_)
    data = np.concatenate(data, axis=0)
    labels = np.concatenate(labels, axis=0)
    return data, labels


class ModelNet40Generator(Dataset):
    
    def __init__(self, mode, data_dir, files_list, num_classes=40, num_points=1024, rot_aug=False):
        """Initialize the ModelNet40Generator class.

        Args:
            mode (str): 'train' or 'test'.
            data_dir (str): Path to the data directory.
            files_list (str): Path to the files list.
            num_classes (int, optional): ModelNet class. Defaults to 40.
            num_points (int, optional): Input PC. Defaults to 1024.
            rot_aug (bool, optional): Augment data. Defaults to False.
        """
        
        assert mode.lower() in ('train', 'val', 'test')
        assert files_list in ('train_files.txt', 'test_files.txt')
        self.data, labels = load_h5_files(data_dir, files_list)
        
        self.mode = mode
        self.num_points = num_points
        self.num_classes = num_classes
        self.num_samples = self.data.shape[0]
        self.rot_aug = rot_aug
        self.labels = np.reshape(labels, (-1,))

    
    def __len__(self) -> int:
        return self.num_samples


    def __getitem__(self, idx):
        indexes = np.random.permutation(np.arange(self.num_points))[:self.num_points]
        X = self.data[idx, indexes, ...]
        y = self.labels[idx, ...]
        y_categorical = torch.from_numpy(np.eye(self.num_classes, dtype='uint8')[y]).long()

        if self.mode == 'train':
            X = self.random_scaling(X)
            # X = self.random_rotation(X)
        if self.rot_aug:
            X = self.random_rotation_Yaxis(X)

        return torch.from_numpy(X).float(), y_categorical.float()


    def random_scaling(self, X):
        # TODO
        """Apply random scaling to the point cloud.

        Args:
            X (np.ndarray): Point cloud data, (N, 3).

        Returns:
            X (np.ndarray): Scaled point cloud data (N, 3).
        """
        X = X[np.newaxis, :, :]
        a = np.random.uniform(low=2. / 3., high=3. / 2., size=[X.shape[0], 1, 3])
        b = np.random.uniform(low=-0.2, high=0.2, size=[X.shape[0], 1, 3])
        return np.squeeze(np.add(np.multiply(a, X), b))


    def generate_3d_rotmat(self):
        # TODO
        """Generate a 3D random rotation matrix.
        Returns:
            np.matrix: A 3D rotation matrix.
        """
        x1, x2, x3 = np.random.rand(3)
        R = np.matrix([[np.cos(2 * np.pi * x1), np.sin(2 * np.pi * x1), 0],
                    [-np.sin(2 * np.pi * x1), np.cos(2 * np.pi * x1), 0],
                    [0, 0, 1]])
        v = np.matrix([[np.cos(2 * np.pi * x2) * np.sqrt(x3)],
                    [np.sin(2 * np.pi * x2) * np.sqrt(x3)],
                    [np.sqrt(1 - x3)]])
        H = np.eye(3) - 2 * v * v.T
        M = -H * R
        return M


    def random_rotation_3d(self, X):
        # TODO
        """Apply random rotation to the point cloud (axis agnostic).

        Args:
            X (np.ndarray): Point cloud data, (N, 3).

        Returns:
            rotated_data (np.ndarray): Rotated point cloud data (N, 3).
        """
        rotation_matrix = self.generate_3d_rotmat()
        rotated_data = np.dot(X.reshape((-1, 3)), rotation_matrix)
        return rotated_data
    
    def random_rotation_Yaxis(self, X):
        # TODO
        """Apply rotation to the point cloud along the Y axis.

        Args:
            X (np.ndarray): Point cloud data, (N, 3).

        Returns:
            X (np.ndarray): Rotated point cloud data along Y-axis (N, 3).
        """
        rot_angle = np.random.uniform(0, 2 * np.pi)
        rot_mat = RotMat(rot_angle, [0,1,0])[:3,:3]
        return np.dot(X, rot_mat)
