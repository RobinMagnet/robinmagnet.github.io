import os
import torch
from torch.nn import functional as F
import numpy as np
from pointnet import PointNetCls
from pointnetpp import PointNetPP
import matplotlib.pyplot as plt
from pdb import set_trace as bp
from tqdm import tqdm

class Trainer(object):
    
    def __init__(self, train_loader, valid_loader, device='cuda',
                 lr=1e-3, weight_decay=1e-4, num_epochs=200,
                 lr_decay_every = 50, lr_decay_rate = 0.5,
                 log_interval=10, save_dir=None, **model_cfg):
        
        """
        pointNet_cls: (nn.Module) class of the PointNet (or ++) model.
        train_loader: (torch.utils.DataLoader) DataLoader for training set
        valid_loader: (torch.utils.DataLoader) DataLoader for validation set
        device: (str) 'cuda' or 'cpu'
        lr: (float) learning rate
        weight_decay: (float) weight decay for optimiser
        num_epochs: (int) number of epochs
        lr_decay_every: (int) decay learning rate every this many epochs
        lr_decay_rate: (float) decay learning rate by this factor
        log_interval: (int) print training stats every this many iterations
        save_dir: (str) directory to save model checkpoints
        model_cfg: (dict) keyword arguments for model
        """
        self.model = self.get_model(model_cfg).to(device)
        self.train_loader = train_loader
        self.valid_loader = valid_loader
        self.device = device
        self.lr = lr
        self.weight_decay = weight_decay
        self.num_epochs = num_epochs
        
        self.optimizer = torch.optim.Adam(self.model.parameters(), lr=self.lr, weight_decay=self.weight_decay)
        self.loss = torch.nn.CrossEntropyLoss()
        
        self.lr_decay_every = lr_decay_every
        self.lr_decay_rate = lr_decay_rate
        self.log_interval = log_interval
        self.save_dir = save_dir
        if not os.path.exists(self.save_dir):
            os.makedirs(self.save_dir)
        
        self.train_losses = []
        self.val_losses = []
        self.train_accs = []
        self.val_accs = []
        
        self.inp_feat = model_cfg.get('inp_feat', 'xyz')
        self.num_eig = model_cfg.get('num_eig', 128)
        if not self.inp_feat in ['xyz', 'xyzn', 'hks', 'wks']:
            raise ValueError('inp_feat must be one of xyz, xyzn, hks, wks')
        
        self.model.to(self.device)
        
    def get_model(self, model_cfg):
        if model_cfg['name'].lower() == 'pointnet':
            return PointNetCls(n_cls=model_cfg['n_cls'],
                               conv_dims=model_cfg['conv_dims'],
                               fc_dims=model_cfg['fc_dims'])
        elif model_cfg['name'].lower() == 'pointnetpp':
            return PointNetPP(inp_dim=model_cfg['inp_dim'],
                               n_cls=model_cfg['n_cls'],
                               fps_pt_list=model_cfg['fps_pt_list'],
                               nsample_list=model_cfg['nsample_list'],
                               radius_list=model_cfg['radius_list'],
                               conv_list=model_cfg['conv_list'],
                               fc_list=model_cfg['fc_list'])
        else:
            raise ValueError('%s must be one of PointNet, PointNet++'%model_cfg['name'])
        
    def compute_HKS(self, verts, faces, num_eig, n_feat):
        """
        TODO: Fill in this function to compute the HKS features for each vertex in the mesh.
        Args:
            verts (torch.Tensor): (N, 3) tensor of vertex positions
            faces (torch.Tensor): (F, 3) tensor of face indices
            num_eig (int): number of eigenvalues to compute
            n_feat (int): number of features to compute
            
        Returns:
            hks (torch.Tensor): (N, n_feat) tensor of HKS features
        """
        return 
    
    def compute_WKS(self, verts, faces, num_eig, num_E):
        """
        TODO: Fill in this function to compute the WKS features for each vertex in the mesh.

        Args:
            verts (torch.Tensor): (N, 3) tensor of vertex positions
            faces (torch.Tensor): (F, 3) tensor of face indices
            num_eig (int): number of eigenvalues to compute
            num_E (int): number of features to compute
            
        Returns:
            wks: torch.Tensor: (N, num_E) tensor of WKS features
        """
        return 
        
    def adjust_lr(self):
        lr = self.lr * self.lr_decay_rate
        for param_group in self.optimizer.param_groups:
            param_group['lr'] = lr 
        
    def forward_step(self, inp):
        """
        Perform a forward step of the model.

        Args:
            inp (torch.Tensor): (N, D) tensor of input features

        Returns:
            pred (torch.Tensor): (N, p_out) tensor of predicted labels.
        """
        inp = inp.to(self.device)
        verts = inp[..., :3].to(self.device)
        norms = inp[..., 3:].to(self.device)
        preds, trans_feat = self.model(inp)
        return preds, trans_feat
    
    def get_feat_loss(self, feat):
        n_batch = feat.shape[0]
        eye_like = torch.eye(feat.shape[1]).to(self.device).unsqueeze(0).repeat(n_batch, 1, 1)
        feat_ortho = torch.bmm(feat, feat.transpose(1, 2))
        cur_rigidity = (feat_ortho - eye_like + 1e-7).abs().norm(p="fro", dim=(-1, -2))
        return cur_rigidity.mean()
        
        
    def get_loss(self, preds, gt_labels, trans_feat):
        clf_loss = self.loss(preds, gt_labels.argmax(dim=1))
        feat_loss = self.get_feat_loss(trans_feat)
        loss = clf_loss + feat_loss * 0.001
        return loss
    
    def train_epoch(self):
        train_loss = 0
        train_acc = 0
        for i, (inp_pts, gt_labels) in enumerate(self.train_loader):
            self.optimizer.zero_grad()
            gt_labels = gt_labels.to(self.device)
            preds, trans_feat = self.forward_step(inp_pts)
            loss = self.get_loss(preds, gt_labels, trans_feat)
            loss.backward()               
            self.optimizer.step()
            train_loss += loss.item()
            pred_labels = torch.max(preds, dim=1).indices
            this_correct = pred_labels.eq(gt_labels.argmax(dim=-1)).sum().item()
            train_acc += this_correct/gt_labels.shape[0]
            
        return train_loss/len(self.train_loader), train_acc/len(self.train_loader)
    
    def valid_epoch(self):
        val_loss = 0
        val_acc = 0
        for i, (inp_pts, gt_labels) in enumerate(self.valid_loader):
            gt_labels = gt_labels.to(self.device)
            preds, trans_feat = self.forward_step(inp_pts)
            loss = self.get_loss(preds, gt_labels, trans_feat)
            val_loss += loss.item()
            pred_labels = torch.max(preds, dim=1).indices
            this_correct = pred_labels.eq(gt_labels.argmax(dim=-1)).sum().item()
            val_acc += this_correct/gt_labels.shape[0]
            
        return val_loss/len(self.valid_loader), val_acc/len(self.valid_loader)

    def run(self):
        for epoch in tqdm(range(self.num_epochs)):
            self.model.train()

            if epoch % self.lr_decay_every == 0:
                self.adjust_lr()
                
            train_ep_loss, train_ep_acc = self.train_epoch()
            self.train_losses.append(train_ep_loss)
            self.train_accs.append(train_ep_acc)
            
            if epoch % self.log_interval == 0:
                val_loss, val_acc = self.valid_epoch()
                self.val_losses.append(val_loss)
                self.val_accs.append(val_acc)
                torch.save(self.model.state_dict(), os.path.join(self.save_dir, 'model_latest.pth'))
                print('Epoch: {:03d}, Train Loss: {:.4f}, Train Acc: {:.4f}, Val Loss: {:.4f}, Val Acc: {:.4f}'.format(epoch,
                                                                                                                       train_ep_loss,
                                                                                                                       train_ep_acc,
                                                                                                                       val_loss,
                                                                                                                       val_acc))
        torch.save(self.model.state_dict(), os.path.join(self.save_dir, 'model_final.pth'))

    def plot_losses(self):
        plt.figure()
        plt.plot(self.train_losses, label='train')
        plt.plot(self.train_accs, label='train acc')
        plt.plot(self.val_losses, label='val')
        plt.plot(self.val_accs, label='val acc')
        plt.legend()
        plt.xlabel('Epoch')
        plt.ylabel('Loss')
        plt.savefig(os.path.join(self.save_dir, 'losses.png'))
        plt.close()
