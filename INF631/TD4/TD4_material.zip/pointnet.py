
from collections import OrderedDict
import torch
import torch.nn as nn
import torch.nn.parallel
import torch.utils.data
from torch.autograd import Variable
import numpy as np
import torch.nn.functional as F
from pdb import set_trace as bp

class InpTransform(nn.Module):
    # TODO
    def __init__(self, inp_dim=3, conv_dims=[64,128,1024], fc_dims=[512,256]):
        super(InpTransform, self).__init__()
        feat_layers = OrderedDict()
        self.latent_dim = conv_dims[-1]
        out_dim = inp_dim**2
        for i in range(len(conv_dims)):
            if i == 0:
                conv = nn.Conv1d(inp_dim, conv_dims[i], 1)
            else:
                conv = nn.Conv1d(conv_dims[i-1], conv_dims[i], 1)
            feat_layers['conv%d'%(i+1)] = conv
            feat_layers['bn%d'%(i+1)] = nn.BatchNorm1d(conv_dims[i])
            feat_layers['relu%d'%(i+1)] = nn.ReLU()
            
        self.feat_layers = nn.Sequential(feat_layers)
        fc_layers = OrderedDict()
        for i in range(len(fc_dims)):
            if i == 0:
                fc = nn.Linear(conv_dims[-1], fc_dims[i])
            else:
                fc = nn.Linear(fc_dims[i-1], fc_dims[i])
            fc_layers['fc%d'%(i+1)] = fc
            fc_layers['bn%d'%(i+1)] = nn.BatchNorm1d(fc_dims[i])
            fc_layers['relu%d'%(i+1)] = nn.ReLU()
        self.fc_layers = nn.Sequential(fc_layers)
        self.fc_last = nn.Linear(fc_dims[-1], out_dim)

    def forward(self, x):
        batchsize = x.size()[0]
        feat_x = self.feat_layers(x)
        feat_x_max = torch.max(feat_x, 2, keepdim=True)[0]
        latent_feat = feat_x_max.view(-1, self.latent_dim)
        
        latent_out = self.fc_layers(latent_feat)
        out = self.fc_last(latent_out)
        iden_vec = torch.eye(3).view(1,9).repeat(batchsize,1).to(x.device)
        x = out + iden_vec
        x = x.view(-1, 3, 3)
        return x


class FeatTransform(nn.Module):
    ## TODO
    def __init__(self, inp_dim=64, conv_dims=[64,128,1024], fc_dims=[512,256]):
        """
        Feature transformation

        Args:
            inp_dim (int, optional): Input feat dim. Defaults to 64.
            conv_dims (list, optional): 1x1 conv feature hidden dim. Defaults to [64,128,1024].
            fc_dims (list, optional): Final MLP dim. Defaults to [512,256].
        """
        super(FeatTransform, self).__init__()
        feat_layers = OrderedDict()
        self.latent_dim = conv_dims[-1]
        for i in range(len(conv_dims)):
            if i == 0:
                conv = nn.Conv1d(inp_dim, conv_dims[i], 1)
            else:
                conv = nn.Conv1d(conv_dims[i-1], conv_dims[i], 1)
            feat_layers['conv%d'%(i+1)] = conv
            feat_layers['bn%d'%(i+1)] = nn.BatchNorm1d(conv_dims[i])
            feat_layers['relu%d'%(i+1)] = nn.ReLU()
        self.feat_layers = nn.Sequential(feat_layers)
        
        fc_layers = OrderedDict()
        for i in range(len(fc_dims)):
            if i == 0:
                fc = nn.Linear(conv_dims[-1], fc_dims[i])
            else:
                fc = nn.Linear(fc_dims[i-1], fc_dims[i])
            fc_layers['fc%d'%(i+1)] = fc
            fc_layers['bn%d'%(i+1)] = nn.BatchNorm1d(fc_dims[i])
            fc_layers['relu%d'%(i+1)] = nn.ReLU()
        self.fc_layers = nn.Sequential(fc_layers)
        self.fc_last = nn.Linear(fc_dims[-1], inp_dim**2)
        self.inp_dim = inp_dim

    def forward(self, x):
        batchsize = x.size()[0]
        feat_x = self.feat_layers(x)
        feat_x_max = torch.max(feat_x, 2, keepdim=True)[0]
        latent_feat = feat_x_max.view(-1, self.latent_dim)
        latent_out = self.fc_layers(latent_feat)
        out = self.fc_last(latent_out)
        iden_vec = torch.eye(self.inp_dim).view(1,self.inp_dim**2).repeat(batchsize,1).to(x.device)
        x = out + iden_vec
        x = x.view(-1, self.inp_dim, self.inp_dim)
        return x

class PointNetfeat(nn.Module):
    
    ## TODO
    def __init__(self, inp_dim=3, conv_dims=[64,128,1024], fc_dims=[512,256]):
        super(PointNetfeat, self).__init__()
        self.inp_trans_l = InpTransform(inp_dim=inp_dim, conv_dims=conv_dims, fc_dims=fc_dims)
        self.conv1 = torch.nn.Conv1d(inp_dim, conv_dims[0], 1)
        self.conv2 = torch.nn.Conv1d(conv_dims[0], conv_dims[1], 1)
        self.conv3 = torch.nn.Conv1d(conv_dims[1], conv_dims[2], 1)
        self.bn1 = nn.BatchNorm1d(conv_dims[0])
        self.bn2 = nn.BatchNorm1d(conv_dims[1])
        self.bn3 = nn.BatchNorm1d(conv_dims[2])
        self.bottleneck_dim = conv_dims[-1]
        self.feat_trans_l = FeatTransform(inp_dim=conv_dims[0], conv_dims=conv_dims, fc_dims=fc_dims)

    def forward(self, inp):
        n_pts = inp.size()[2]
        inp_trans = self.inp_trans_l(inp)
        out = inp.transpose(2, 1)
        out = torch.bmm(out, inp_trans)
        out = out.transpose(2, 1)
        out = F.relu(self.bn1(self.conv1(out)))

        feat_trans = self.feat_trans_l(out)
        out = out.transpose(2,1)
        out = torch.bmm(out, feat_trans)
        out = out.transpose(2,1)
        out = F.relu(self.bn2(self.conv2(out)))
        out = self.bn3(self.conv3(out))
        out = torch.max(out, 2, keepdim=True)[0]
        out = out.view(-1, self.bottleneck_dim)
        return out, feat_trans


class PointNetCls(nn.Module):
    ## TODO
    def __init__(self, n_cls, conv_dims=[64,128,1024], fc_dims=[512,256]):
        """
        PointNet classification network

        Args:
            n_cls (int): Number of ModelNet classes
            conv_dims (list, optional): PointNetFeat dimensions. Defaults to [64,128,1024].
            fc_dims (list, optional): FC layer dims. Defaults to [512,256].
        """
        super(PointNetCls, self).__init__()
        self.feat = PointNetfeat(inp_dim=3, conv_dims=conv_dims, fc_dims=fc_dims)
        self.fc1 = nn.Linear(conv_dims[-1], fc_dims[0])
        self.fc2 = nn.Linear(fc_dims[0], fc_dims[1])
        self.fc3 = nn.Linear(256, n_cls)
        self.dropout = nn.Dropout(p=0.3)
        self.bn1 = nn.BatchNorm1d(fc_dims[0])
        self.bn2 = nn.BatchNorm1d(fc_dims[1])
        self.relu = nn.ReLU()

    def forward(self, inp):
        out_f, trans_feat = self.feat(inp.transpose(2,1))
        x = F.relu(self.bn1(self.fc1(out_f)))
        x = F.relu(self.bn2(self.dropout(self.fc2(x))))
        x = self.fc3(x)
        return F.log_softmax(x, dim=-1), trans_feat
