# point_utils.py
import torch
import numpy as np
from pdb import set_trace as bp

def fps_batch(xyz, npoint):
    # TODO
    """
    Compute farthest point sampling.
    
    xyz: (B, N, C), input points. C can be 3 or n_features.
    npoint: number of samples
    
    Returns
    fps_idx: (B, npoint, C) sampled points
    """
    device = xyz.device
    B, N, C = xyz.shape
    fps_idx = torch.zeros(B, npoint).to(device).long()
    distance = torch.ones(B, N).to(device) * 1e10
    farthest = torch.randint(0, N, (B,)).to(device).long()
    batch_idx = torch.arange(B).to(device).long()
    for i in range(npoint):
        fps_idx[:, i] = farthest
        centroid = xyz[batch_idx, farthest, :].view(B, 1, C)
        dist = ((xyz - centroid) ** 2).sum(-1).sqrt()
        mask = dist < distance
        distance[mask] = dist[mask]
        farthest = torch.max(distance, -1)[1]
    return fps_idx


def batched_indexing(points, idx):
    """
    Basically do advanced indexing.
    https://numpy.org/devdocs/user/basics.indexing.html#advanced-indexing
    
    Input:
        points: input points data, [B, N, C]
        idx: sample index data, [B, S]
    Return:
        new_points:, indexed points data, [B, S, C]
    """
    device = points.device
    B = points.shape[0]
    batch_idx = torch.arange(B, dtype=torch.long).to(device)
    batch_idx = batch_idx.view([-1]+[1]*(len(idx.size())-1))
    batch_idx = batch_idx.repeat((1,)+idx.size()[1:])
    new_points = points[batch_idx, idx, :]
    return new_points

def query_ball_point(radius, nsample, inp_pc, query_pc):
    # TODO
    """
    Query ball point with radius and nsample.

    Args:
        radius (int): Radius of ball query.
        nsample (int): Max samples to consider.
        xyz (torch.Tensor): (B, N, 3) input points.
        query_pc (torch.Tensor): (B, S, 3) xyz coordinates of the query points.

    Returns:
        group_idx: (torch.Tensor): (B, S, nsample) grouped point idx
    """

    device = inp_pc.device
    B, N, C = inp_pc.shape
    _, S, _ = query_pc.shape
    group_idx = torch.arange(N, dtype=torch.long).to(device).view(1, 1, N).repeat([B, S, 1])
    sqrdists = torch.cdist(query_pc, inp_pc)
    group_idx[sqrdists > radius ** 2] = N
    group_idx = group_idx.sort(dim=-1)[0][:, :, :nsample]
    group_first = group_idx[:, :, 0].view(B, S, 1).repeat([1, 1, nsample])
    mask = group_idx == N
    group_idx[mask] = group_first[mask]
    return group_idx
