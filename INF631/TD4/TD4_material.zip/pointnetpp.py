# pointnet2
import torch
import torch.nn as nn
import torch.nn.functional as F
from point_utils import batched_indexing, fps_batch, query_ball_point
from pdb import set_trace as bp


class PointNetMSG(nn.Module):
    def __init__(self, npoint, radius_list, kNN_list, in_channel, mlp_list,
                 concat=False):
        
        # NotTODO
        
        """
        PointNet Set Abstraction (MSG) module with shared MLP.
        Accumulate features across different radius and use max pooling.

        Args:
            npoint (int): number of points for FPS sampling.
            radius_list (list): list of radius.
            kNN_list (list): list of kNN points for each radius.
            in_channel (int): input channel.
            mlp_list (list): list of output channel for each MLP.
            concat (bool, optional): Concatenate xyz coodinates to features.
        """
        super(PointNetMSG, self).__init__()
        self.npoint = npoint
        self.radius_list = radius_list
        self.kNN_list = kNN_list
        self.concat = concat
        self.conv_blocks = nn.ModuleList()
        self.bn_blocks = nn.ModuleList()
        self.mlp_list = mlp_list
        self.in_channel = in_channel

        ## Each radius needs a MLP
        for i in range(len(mlp_list)):
            convs = nn.ModuleList()
            bns = nn.ModuleList()
            last_channel = in_channel + 3 if self.concat else in_channel
            for out_channel in mlp_list[i]:
                convs.append(nn.Conv2d(last_channel, out_channel, 1))
                bns.append(nn.BatchNorm2d(out_channel))
                last_channel = out_channel
            self.conv_blocks.append(convs)
            self.bn_blocks.append(bns)

    def forward(self, xyz, points=None):
        
        # TODO: Full method

        """
        Sample, Group, sample and aggregate points.
        Args:
            xyz (torch.Tensor): (B, N, 3) xyz coordinates.
            points (torch.Tensor, optional): (B, N, 3) previous xyz coordinates or features

        Returns:
            fps_xyz: (B, npoint, 3) xyz coordinates of sampled points.
            new_points_concat: (B, npoint, \sum_k(mlp[k][-1])) aggregated features.
        """

        B, N, C = xyz.shape
        fps_xyz = batched_indexing(xyz, fps_batch(xyz, self.npoint))
        new_points_list = []
        for i, radius in enumerate(self.radius_list):
            group_idx = query_ball_point(radius, self.kNN_list[i], xyz, fps_xyz)
            grouped_xyz = batched_indexing(xyz, group_idx)
            # Center the points to local coordinate
            grouped_xyz -= fps_xyz.view(B, self.npoint, 1, C)
            if points is not None:
                grouped_points = batched_indexing(points, group_idx)
                grouped_points = torch.cat([grouped_points, grouped_xyz], dim=-1)
            else:
                grouped_points = grouped_xyz

            grouped_points = grouped_points.permute(0, 3, 2, 1)  # [B, D, K, S]
            for j in range(len(self.conv_blocks[i])):
                conv = self.conv_blocks[i][j]
                bn = self.bn_blocks[i][j]
                grouped_points = F.relu(bn(conv(grouped_points)), inplace=True)
            new_points = torch.max(grouped_points, 2)[0]  
            new_points_list.append(new_points)
        new_points_concat = torch.cat(new_points_list, dim=1).transpose(2,1)
        return fps_xyz, new_points_concat

    
class PointNetGroup(nn.Module):

    def __init__(self, in_channel, mlp_list):
        # NotTODO
        super(PointNetGroup, self).__init__()
        self.mlp_convs = nn.ModuleList()
        self.mlp_bns = nn.ModuleList()
        last_channel = in_channel
        for out_channel in mlp_list:
            self.mlp_convs.append(nn.Conv2d(last_channel, out_channel, 1))
            self.mlp_bns.append(nn.BatchNorm2d(out_channel))
            last_channel = out_channel

    def forward(self, xyz, points):
        # TODO: Full method
        """
        Input:
            xyz: input points position data, [B, N, C]
            points: xyz [B, M, C] from prev layers
        Return:
            new_xyz: sampled points position data, [B, C, S]
            new_points_concat: sample points feature data, [B, D', S]
        """
        B, C, N = xyz.shape

        new_points = torch.cat([xyz.view(B, 1, N, C), points.view(B, 1, N, -1)], dim=-1)
        # new_xyz: sampled points position data, [B, npoint, C]
        # new_points: sampled points data, [B, npoint, nsample, C+D]
        new_points = new_points.permute(0, 3, 2, 1) # [B, C+D, nsample,npoint]
        for i, conv in enumerate(self.mlp_convs):
            bn = self.mlp_bns[i]
            new_points =  F.relu(bn(conv(new_points)), inplace=True)

        new_points = torch.max(new_points, 2)[0]
        return new_points


class PointNetPP(nn.Module):
    
    # TODO
    
    def __init__(self, inp_dim, n_cls, fps_pt_list, kNN_list, radius_list, conv_list, fc_list):
        """
        PointNet++ classification network.

        Args:
            inp_dim (int): Input dimension.
            n_cls (int): Number of classes.
            fps_pt_list (list): Number of points for FPS sampling.
            kNN_list (list): NN points for each radius.
            radius_list (list): Radius for each FPS sampling.
            conv_list (list): List of list of output channel for each MLP.
            fc_list (list): List of output channel for each 1x1 MLP.
        """
        
        super(PointNetPP, self).__init__()
        self.msg_1 = PointNetMSG(n_point=fps_pt_list[0], radius_list=radius_list[0], kNN_list=kNN_list[0], in_channel=inp_dim,
                                 mlp_list=list(conv_list[0]))
        out_1 = sum([i[-1] for i in conv_list[0]])
        self.msg_2 = PointNetMSG(n_point=fps_pt_list[1], radius_list=radius_list[1],
                               kNN_list=kNN_list[1], in_channel=out_1, mlp_list=list(conv_list[1]), concat=True)
        out_2 = sum([i[-1] for i in conv_list[1]])
        self.group = PointNetGroup(out_2+3, list(conv_list[2]))
        
        self.bottleneck_size = fc_list[0]
        self.fc1 = nn.Linear(fc_list[0], fc_list[1])
        self.bn1 = nn.BatchNorm1d(fc_list[1])
        self.drop1 = nn.Dropout(0.3)
        self.fc2 = nn.Linear(fc_list[1], fc_list[2])
        self.bn2 = nn.BatchNorm1d(fc_list[2])
        self.drop2 = nn.Dropout(0.3)
        self.fc3 = nn.Linear(fc_list[2], n_cls)

    def forward(self, xyz):
        B, _, _ = xyz.shape
        msg1_xyz, msg1_feat = self.msg_1(xyz)
        msg2_xyz, msg2_feat = self.msg_2(msg1_xyz, msg1_feat)
        grouped_feat = self.group(msg2_xyz, msg2_feat)
        x = grouped_feat.view(B, self.bottleneck_size)
        x = self.drop1(F.relu(self.bn1(self.fc1(x))))
        x = self.drop2(F.relu(self.bn2(self.fc2(x))))
        x = self.fc3(x)
        x = F.log_softmax(x, -1)
        return x, grouped_feat
